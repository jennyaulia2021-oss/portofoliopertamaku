// ===== 1. MENU UNTUK LAYAR KECIL =====
const menuToggle = document.getElementById("menuToggle");
const navLinks = document.getElementById("navLinks");

// Klik tombol "Menu" untuk membuka/menutup daftar menu
menuToggle.addEventListener("click", function () {
  const terbuka = navLinks.classList.toggle("open");
  menuToggle.setAttribute("aria-expanded", terbuka);
});

// Setelah memilih menu, daftar menu ditutup lagi
navLinks.querySelectorAll("a").forEach(function (link) {
  link.addEventListener("click", function () {
    navLinks.classList.remove("open");
    menuToggle.setAttribute("aria-expanded", "false");
  });
});

// ===== 2. PROGRESS BAR SKILLS =====
// Bar baru terisi ketika bagian Skills terlihat di layar
const daftarSkill = document.querySelectorAll(".skill");

function isiBar(skill) {
  const level = skill.dataset.level; // mengambil angka dari data-level
  skill.querySelector(".bar-fill").style.width = level + "%";
}

if ("IntersectionObserver" in window) {
  const pengamat = new IntersectionObserver(function (entries) {
    entries.forEach(function (entry) {
      if (entry.isIntersecting) {
        isiBar(entry.target);
        pengamat.unobserve(entry.target); // cukup sekali
      }
    });
  }, { threshold: 0.4 });

  daftarSkill.forEach(function (skill) { pengamat.observe(skill); });
} else {
  // Cadangan untuk browser lama: langsung isi semua bar
  daftarSkill.forEach(isiBar);
}

// ===== 3. DIALOG "LIHAT DETAIL" =====
const dialog = document.getElementById("detailDialog");
const dialogTitle = document.getElementById("dialogTitle");
const dialogText = document.getElementById("dialogText");

document.querySelectorAll(".detail-btn").forEach(function (tombol) {
  tombol.addEventListener("click", function () {
    dialogTitle.textContent = tombol.dataset.title;
    dialogText.textContent = tombol.dataset.text;
    dialog.showModal(); // menampilkan jendela di atas halaman
  });
});

document.getElementById("dialogClose").addEventListener("click", function () {
  dialog.close();
});

// ===== 4. VALIDASI FORMULIR KONTAK =====
const form = document.getElementById("contactForm");
const status = document.getElementById("formStatus");

// Menampilkan atau menghapus pesan error pada satu kolom
function setError(idKolom, pesan) {
  const kolom = document.getElementById(idKolom);
  const teksError = document.getElementById(idKolom + "Error");
  teksError.textContent = pesan;
  kolom.parentElement.classList.toggle("invalid", pesan !== "");
}

// Pola email sederhana: ada teks, tanda @, teks, titik, teks
const polaEmail = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

form.addEventListener("submit", function (event) {
  event.preventDefault(); // mencegah halaman dimuat ulang
  status.textContent = "";

  const nama = document.getElementById("name").value.trim();
  const email = document.getElementById("email").value.trim();
  const pesan = document.getElementById("message").value.trim();
  let valid = true;

  if (nama.length < 2) {
    setError("name", "Nama minimal 2 karakter.");
    valid = false;
  } else {
    setError("name", "");
  }

  if (!polaEmail.test(email)) {
    setError("email", "Masukkan alamat email yang valid, misalnya nama@example.com.");
    valid = false;
  } else {
    setError("email", "");
  }

  if (pesan.length < 10) {
    setError("message", "Pesan minimal 10 karakter.");
    valid = false;
  } else {
    setError("message", "");
  }

  if (valid) {
    // Belum ada backend, jadi pesan TIDAK dikirim ke mana pun
    status.textContent = "Isian sudah benar. Formulir ini hanya latihan, jadi pesan tidak dikirim.";
    form.reset();
  }
});

// ===== 5. TAHUN OTOMATIS DI FOOTER =====
document.getElementById("year").textContent = new Date().getFullYear();
